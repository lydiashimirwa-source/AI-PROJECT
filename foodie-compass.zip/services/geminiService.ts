
import { GoogleGenAI, Type } from "@google/genai";
import type { UserPreferences, Restaurant } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      name: {
        type: Type.STRING,
        description: "A creative and fitting name for the restaurant."
      },
      cuisine: {
        type: Type.STRING,
        description: "The primary cuisine type of the restaurant."
      },
      address: {
        type: Type.STRING,
        description: "A realistic-sounding street address in the specified city."
      },
      rating: {
        type: Type.NUMBER,
        description: "A rating out of 5 stars, can be a decimal like 4.7."
      },
      budget: {
        type: Type.STRING,
        description: "A budget indicator like $, $$, or $$$."
      },
      summary: {
        type: Type.STRING,
        description: "A short, enticing one-paragraph summary of the restaurant, highlighting its pros and cons."
      },
      signatureDish: {
        type: Type.STRING,
        description: "A must-try signature dish from their menu."
      },
    },
    required: ["name", "cuisine", "address", "rating", "budget", "summary", "signatureDish"],
  },
};

export const findRestaurants = async (preferences: UserPreferences): Promise<Restaurant[]> => {
  const dietaryNeeds = preferences.dietary.length > 0 ? preferences.dietary.join(', ') : 'None';
  
  const prompt = `
    You are a world-class restaurant recommendation engine called "Foodie Compass".
    Based on the following user preferences, suggest 6 fictional but realistic-sounding restaurants in ${preferences.location}.

    Preferences:
    - Cuisines: ${preferences.cuisines.join(', ')}
    - Budget: ${preferences.budget}
    - Dietary Needs: ${dietaryNeeds}
    - Vibe/Mood: ${preferences.mood}

    For each restaurant, provide all the requested details. Ensure the addresses are plausible for the city of ${preferences.location}.
    The summary for each restaurant should be compelling and give a feel for the atmosphere and food quality.
    Return the response as a valid JSON array that matches the provided schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.8,
      },
    });

    const jsonString = response.text.trim();
    const result = JSON.parse(jsonString);
    
    // Basic validation to ensure we got an array
    if (Array.isArray(result)) {
      return result as Restaurant[];
    } else {
      console.error("Gemini API did not return a valid array:", result);
      return [];
    }

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to fetch restaurant suggestions from AI.");
  }
};
