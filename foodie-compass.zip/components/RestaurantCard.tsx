
import React, { useState } from 'react';
import type { Restaurant } from '../types';
import RestaurantDetailModal from './RestaurantDetailModal';

interface RestaurantCardProps {
  restaurant: Restaurant;
}

const StarIcon: React.FC<{ className?: string, isFilled: boolean }> = ({ className, isFilled }) => (
  <svg className={className} fill={isFilled ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.539 1.118l-3.975-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.196-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118L2.05 10.1c-.783-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
  </svg>
);


const RestaurantCard: React.FC<RestaurantCardProps> = ({ restaurant }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      stars.push(<StarIcon key={i} className="w-5 h-5" isFilled={i <= rating} />);
    }
    return stars;
  };

  const randomImageId = Math.floor(Math.random() * 200) + 100;

  return (
    <>
      <div 
        className="bg-white rounded-2xl shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300 cursor-pointer flex flex-col"
        onClick={() => setIsModalOpen(true)}
      >
        <img 
          className="h-48 w-full object-cover" 
          src={`https://picsum.photos/id/${randomImageId}/400/300`} 
          alt={`Food from ${restaurant.name}`} 
        />
        <div className="p-6 flex flex-col flex-grow">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-bold text-xl text-dark truncate pr-2">{restaurant.name}</h3>
            <div className="flex items-center text-secondary-500 bg-yellow-100 text-yellow-800 font-bold text-sm px-2 py-1 rounded-full">
              {renderStars(restaurant.rating)}
              <span className="ml-1">{restaurant.rating.toFixed(1)}</span>
            </div>
          </div>
          <p className="text-sm text-gray-500 font-medium mb-1">{restaurant.cuisine} &middot; {restaurant.budget}</p>
          <p className="text-gray-600 text-sm flex-grow">{restaurant.summary.substring(0, 100)}...</p>
          <div className="mt-4 pt-4 border-t border-gray-100">
             <p className="text-xs text-gray-400">SIGNATURE DISH</p>
             <p className="font-semibold text-primary">{restaurant.signatureDish}</p>
          </div>
        </div>
      </div>
      {isModalOpen && <RestaurantDetailModal restaurant={restaurant} onClose={() => setIsModalOpen(false)} />}
    </>
  );
};

export default RestaurantCard;
