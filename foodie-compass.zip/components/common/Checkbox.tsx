
import React from 'react';

interface CheckboxProps {
  label: string;
  name: string;
  checked: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const Checkbox: React.FC<CheckboxProps> = ({ label, name, checked, onChange }) => {
  return (
    <label className="flex items-center space-x-3 cursor-pointer p-3 rounded-lg transition-colors hover:bg-yellow-50">
      <input
        type="checkbox"
        name={name}
        checked={checked}
        onChange={onChange}
        className="form-checkbox h-5 w-5 text-primary rounded border-gray-300 focus:ring-primary focus:ring-opacity-50"
      />
      <span className="text-gray-700 font-medium">{label}</span>
    </label>
  );
};

export default Checkbox;
