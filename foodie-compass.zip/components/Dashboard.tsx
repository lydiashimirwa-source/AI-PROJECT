
import React from 'react';
import type { UserPreferences, Restaurant } from '../types';
import RestaurantCard from './RestaurantCard';

interface DashboardProps {
  preferences: UserPreferences;
  restaurants: Restaurant[];
  isLoading: boolean;
  error: string | null;
}

const SkeletonCard: React.FC = () => (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden animate-pulse">
      <div className="h-48 bg-gray-300"></div>
      <div className="p-6">
        <div className="h-6 w-3/4 bg-gray-300 rounded mb-2"></div>
        <div className="h-4 w-1/2 bg-gray-300 rounded mb-4"></div>
        <div className="h-4 w-full bg-gray-200 rounded mb-2"></div>
        <div className="h-4 w-full bg-gray-200 rounded mb-2"></div>
        <div className="h-4 w-5/6 bg-gray-200 rounded"></div>
      </div>
    </div>
  );

const Dashboard: React.FC<DashboardProps> = ({ preferences, restaurants, isLoading, error }) => {
  return (
    <div>
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-dark">Today's Picks For You</h2>
        <p className="text-gray-600 mt-2">AI-powered suggestions based on your craving for <span className="font-semibold text-primary">{preferences.mood}</span></p>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg relative max-w-2xl mx-auto" role="alert">
          <strong className="font-bold">Oops! </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array.from({ length: 6 }).map((_, index) => (
                <SkeletonCard key={index} />
            ))}
        </div>
      )}

      {!isLoading && !error && restaurants.length > 0 && (
         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {restaurants.map((restaurant, index) => (
                <RestaurantCard key={`${restaurant.name}-${index}`} restaurant={restaurant} />
            ))}
        </div>
      )}

      {!isLoading && !error && restaurants.length === 0 && (
         <div className="text-center py-16">
            <h3 className="text-xl font-semibold text-gray-700">No restaurants found.</h3>
            <p className="text-gray-500 mt-2">Try searching again with different preferences.</p>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
