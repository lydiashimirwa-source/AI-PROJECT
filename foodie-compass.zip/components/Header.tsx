
import React from 'react';
import Button from './common/Button';

interface HeaderProps {
  onSearchAgain?: () => void;
}

const ForkSpoonIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="currentColor">
        <path d="M16 3C16.5523 3 17 3.44772 17 4V10C17 10.5523 16.5523 11 16 11H15V21C15 21.5523 14.5523 22 14 22H10C9.44772 22 9 21.5523 9 21V11H8C7.44772 11 7 10.5523 7 10V4C7 3.44772 7.44772 3 8 3H9V6H10V3H14V6H15V3H16Z"/>
    </svg>
);


const Header: React.FC<HeaderProps> = ({ onSearchAgain }) => {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 md:px-8 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <ForkSpoonIcon className="h-8 w-8 text-primary" />
          <h1 className="text-2xl font-bold text-primary tracking-tight">Foodie Compass</h1>
        </div>
        {onSearchAgain && (
          <Button variant="secondary" onClick={onSearchAgain}>
            New Search
          </Button>
        )}
      </div>
    </header>
  );
};

export default Header;
