
import React from 'react';
import type { Restaurant } from '../types';
import Button from './common/Button';

interface RestaurantDetailModalProps {
  restaurant: Restaurant;
  onClose: () => void;
}

const StarIcon: React.FC<{ className?: string, isFilled: boolean }> = ({ className, isFilled }) => (
    <svg className={className} fill={isFilled ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.539 1.118l-3.975-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.196-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118L2.05 10.1c-.783-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
    </svg>
  );

const RestaurantDetailModal: React.FC<RestaurantDetailModalProps> = ({ restaurant, onClose }) => {
    const randomImageId = Math.floor(Math.random() * 200) + 100;
  
    const renderStars = (rating: number) => {
        const stars = [];
        for (let i = 1; i <= 5; i++) {
          stars.push(<StarIcon key={i} className="w-6 h-6 text-secondary" isFilled={i <= rating} />);
        }
        return stars;
    };


  return (
    <div 
        className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4"
        onClick={onClose}
    >
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative">
            <img 
                className="h-64 w-full object-cover rounded-t-2xl" 
                src={`https://picsum.photos/id/${randomImageId}/800/400`} 
                alt={`Food from ${restaurant.name}`} 
            />
            <button 
                onClick={onClose} 
                className="absolute top-4 right-4 bg-white rounded-full p-2 hover:bg-gray-200 transition-colors"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-dark" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <div className="p-8">
          <div className="flex flex-col md:flex-row justify-between md:items-start mb-4">
              <div>
                  <h2 className="text-4xl font-bold text-primary">{restaurant.name}</h2>
                  <p className="text-lg text-gray-500 mt-1">{restaurant.cuisine} &middot; {restaurant.address}</p>
              </div>
              <div className="flex items-center mt-3 md:mt-0 text-yellow-500 bg-yellow-100 text-yellow-800 font-bold text-lg px-4 py-2 rounded-full">
                {renderStars(restaurant.rating)}
                <span className="ml-2 text-2xl">{restaurant.rating.toFixed(1)}</span>
              </div>
          </div>

          <div className="border-t border-b border-gray-200 my-6 py-6">
            <h4 className="text-sm font-semibold uppercase text-gray-400 mb-3">AI Review Summary</h4>
            <p className="text-gray-700 leading-relaxed">{restaurant.summary}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <h4 className="text-sm font-semibold uppercase text-gray-400 mb-2">Signature Dish</h4>
              <p className="text-xl font-bold text-accent">{restaurant.signatureDish}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold uppercase text-gray-400 mb-2">Budget</h4>
              <p className="text-xl font-bold text-dark">{restaurant.budget}</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <Button className="w-full">Reserve a Table</Button>
            <Button variant="secondary" className="w-full">Order for Pickup</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantDetailModal;
