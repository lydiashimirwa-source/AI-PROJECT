
import React, { useState } from 'react';
import type { UserPreferences } from '../types';
import { CUISINE_OPTIONS, BUDGET_OPTIONS, DIETARY_OPTIONS, MOOD_OPTIONS } from '../constants';
import Button from './common/Button';
import Checkbox from './common/Checkbox';

interface OnboardingProps {
  onComplete: (preferences: UserPreferences) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [location, setLocation] = useState('San Francisco, CA');
  const [cuisines, setCuisines] = useState<string[]>([]);
  const [budget, setBudget] = useState('$$');
  const [dietary, setDietary] = useState<string[]>([]);
  const [mood, setMood] = useState('Casual Meal');
  const [isLoading, setIsLoading] = useState(false);

  const handleCuisineChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setCuisines(prev => checked ? [...prev, name] : prev.filter(c => c !== name));
  };

  const handleDietaryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setDietary(prev => checked ? [...prev, name] : prev.filter(d => d !== name));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    onComplete({ location, cuisines, budget, dietary, mood });
  };

  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-2xl shadow-lg">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-dark">Find Your Next Favorite Meal</h2>
        <p className="text-gray-600 mt-2">Tell us what you're craving, and our AI will find the perfect spot for you.</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Location */}
        <div>
          <label htmlFor="location" className="block text-lg font-semibold text-gray-700 mb-2">Where are you dining?</label>
          <input
            type="text"
            id="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary"
            placeholder="e.g., New York, NY"
            required
          />
        </div>

        {/* Cuisines */}
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">What cuisines are you in the mood for?</h3>
          <p className="text-sm text-gray-500 mb-4">Select up to 3.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {CUISINE_OPTIONS.map(cuisine => (
              <Checkbox key={cuisine} label={cuisine} name={cuisine} checked={cuisines.includes(cuisine)} onChange={handleCuisineChange} />
            ))}
          </div>
        </div>

        {/* Budget */}
        <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">What's your budget?</h3>
            <div className="flex flex-wrap gap-3">
            {BUDGET_OPTIONS.map(opt => (
                <label key={opt.value} className={`cursor-pointer p-3 px-5 rounded-full border-2 transition-all ${budget === opt.value ? 'bg-primary text-white border-primary' : 'bg-white text-dark border-gray-300 hover:border-primary'}`}>
                <input
                    type="radio"
                    name="budget"
                    value={opt.value}
                    checked={budget === opt.value}
                    onChange={(e) => setBudget(e.target.value)}
                    className="sr-only"
                />
                {opt.label}
                </label>
            ))}
            </div>
        </div>

        {/* Dietary Needs */}
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Any dietary restrictions?</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {DIETARY_OPTIONS.map(diet => (
              <Checkbox key={diet} label={diet} name={diet} checked={dietary.includes(diet)} onChange={handleDietaryChange} />
            ))}
          </div>
        </div>
        
        {/* Mood/Vibe */}
        <div>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">What's the vibe?</h3>
            <select
            value={mood}
            onChange={(e) => setMood(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-primary"
            >
            {MOOD_OPTIONS.map(option => (
                <option key={option} value={option}>{option}</option>
            ))}
            </select>
        </div>


        <div className="text-center pt-4">
          <Button type="submit" isLoading={isLoading} className="w-full md:w-1/2 text-lg">
            Discover Restaurants
          </Button>
        </div>
      </form>
    </div>
  );
};

export default Onboarding;
