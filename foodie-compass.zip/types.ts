
export interface UserPreferences {
  location: string;
  cuisines: string[];
  budget: string;
  dietary: string[];
  mood: string;
}

export interface Restaurant {
  name: string;
  cuisine: string;
  address: string;
  rating: number;
  budget: string;
  summary: string;
  signatureDish: string;
}
