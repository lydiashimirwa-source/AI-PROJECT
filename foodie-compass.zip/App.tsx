
import React, { useState, useCallback } from 'react';
import type { UserPreferences, Restaurant } from './types';
import Onboarding from './components/Onboarding';
import Dashboard from './components/Dashboard';
import Header from './components/Header';
import { findRestaurants } from './services/geminiService';

const App: React.FC = () => {
  const [hasOnboarded, setHasOnboarded] = useState(false);
  const [userPreferences, setUserPreferences] = useState<UserPreferences | null>(null);
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleOnboardingComplete = useCallback(async (preferences: UserPreferences) => {
    setUserPreferences(preferences);
    setHasOnboarded(true);
    setIsLoading(true);
    setError(null);
    setRestaurants([]);

    try {
      const results = await findRestaurants(preferences);
      setRestaurants(results);
    } catch (err) {
      setError('Failed to find restaurants. Please try adjusting your preferences.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleSearchAgain = useCallback(() => {
    setHasOnboarded(false);
    setUserPreferences(null);
    setRestaurants([]);
    setError(null);
  }, []);

  return (
    <div className="min-h-screen bg-light text-dark font-sans">
      <Header onSearchAgain={hasOnboarded ? handleSearchAgain : undefined} />
      <main className="container mx-auto p-4 md:p-8">
        {!hasOnboarded || !userPreferences ? (
          <Onboarding onComplete={handleOnboardingComplete} />
        ) : (
          <Dashboard
            preferences={userPreferences}
            restaurants={restaurants}
            isLoading={isLoading}
            error={error}
          />
        )}
      </main>
    </div>
  );
};

export default App;
