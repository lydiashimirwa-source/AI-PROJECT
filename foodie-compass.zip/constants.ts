
export const CUISINE_OPTIONS = [
  "Italian", "Mexican", "Japanese", "Chinese", "Indian", "French", "Thai", "Vietnamese", "Greek", "Spanish", "Korean", "American"
];

export const BUDGET_OPTIONS = [
  { value: "$", label: "Inexpensive ($)" },
  { value: "$$", label: "Moderate ($$)" },
  { value: "$$$", label: "Pricey ($$$)" },
  { value: "$$$$", label: "Ultra High-End ($$$$)" },
];

export const DIETARY_OPTIONS = [
  "Vegetarian", "Vegan", "Gluten-Free", "Halal", "Kosher", "Dairy-Free"
];

export const MOOD_OPTIONS = [
  "Quick Snack", "Casual Meal", "Fine Dining", "Local Specialty", "Hidden Gem", "Trendy Spot", "Family Friendly"
];
